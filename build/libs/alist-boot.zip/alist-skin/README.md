## 全局｜自定义头部
```html
<script src="/static/skin.js"></script>
```